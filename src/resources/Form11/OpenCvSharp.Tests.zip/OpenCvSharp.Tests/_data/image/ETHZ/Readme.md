# seq03-img-left
This folder image files are downloaded and extracted from https://data.vision.ee.ethz.ch/cvl/aess/cvpr2008/seq03-img-left.tar.gz.
This folder includes only first 21 images.
