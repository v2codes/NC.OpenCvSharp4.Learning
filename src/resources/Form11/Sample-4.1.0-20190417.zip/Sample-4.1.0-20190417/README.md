# opencvsharp_samples

-	`SamplesCS` 	C# (.NET Framework) samples
-	`SamplesCore` C# (.NET Core) samples
- `SamplesVB`  VB.NET samples
-	`SampleBase` 	common library
